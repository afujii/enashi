# 参照：https://qrunch.net/@predora005/entries/tNPJgBIVfejaZbkM?ref=qrunch
import requests
from bs4 import BeautifulSoup


#岐阜県恵那市の2019年11月の1か月データ
url ="https://www.data.jma.go.jp/obd/stats/etrn/view/daily_a1.php?prec_no=52&block_no=0493&year=2019&month=11&day=&view="


# 指定URLのHTMLデータを取得  
html = requests.get(url)  
#print(html.text)  


# BeautifulSoupでHTMLを解析  
soup = BeautifulSoup(html.content, "html.parser")

# id='tablefix2'の<table>を抽出(ブラウザで対象データのタグ名を確認する)

table1 = soup.find('table', id='tablefix1')  

# table1内の全thを抽出  
th_all = table1.find_all('th')
print(th_all)

"""
[<th rowspan="3" scope="col">日</th>, <th colspan="3" scope="colgroup">降水量(mm)</th>,
<th colspan="3" scope="colgroup">気温(℃)</th>, <th colspan="6" scope="colgroup">風向・風速(m/s)</th>,
<th rowspan="3" scope="col">日照<br/>時間<br/>(h)</th>, <th colspan="2" scope="colgroup">雪(cm)</th>,
<th rowspan="2" scope="col">合計</th>, <th colspan="2" scope="colgroup">最大</th>,
<th rowspan="2" scope="col">平均</th>, <th rowspan="2" scope="col">最高</th>,
<th rowspan="2" scope="col">最低</th>, <th rowspan="2" scope="col">平均<br/>風速</th>,
<th colspan="2" scope="colgroup">最大風速</th>, <th colspan="2" scope="colgroup">最大瞬間風速</th>,
<th rowspan="2" scope="col">最多<br/>風向</th>, <th scope="colgroup">降雪</th>,
<th scope="colgroup">最深積雪</th>, <th scope="col">1時間</th>, <th scope="col">10分間</th>,
<th scope="col">風速</th>, <th scope="col">風向</th>, <th scope="col">風速</th>, <th scope="col">風向</th>,
<th scope="col">合計</th>, <th scope="col">値</th>]
"""

# 列タイトルをリストに格納する  
table1_column = []  
for th in th_all:
    table1_column.append(th.string)
    
# table1内の全trを抽出。      
tr_all = table1.find_all('tr')  
tr_all = tr_all[3:] # blog 解説では、１としているが恵那データでは、3行目から

n_cols = 3 # 平均（気温）、最高気温、最低気温の3データのみ（とりあえず）活用
n_rows = len(tr_all)

import numpy as np

ndarry = np.zeros((n_rows, n_cols))  

# 各行のデータをndarrayに格納する  
for d,tr in enumerate(tr_all):  
    td_all = tr.find_all('td')
    tmp = [td.string for td in td_all] 
    #print(tmp[4:7])
    ndarry[d,:]=tmp[4:7]

#ndarry に格納されているのは、30日分の平均、最高、最低のデータ（2019年11月分）
import pandas as pd

items = ['平均','最高気温','最低気温']
df = pd.DataFrame(data=ndarry,columns= items)
df.to_csv("./table1.csv")  
