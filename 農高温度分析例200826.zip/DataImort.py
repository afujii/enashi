import xlrd


book = xlrd.open_workbook('DataR1-R2.xls')
for name in book.sheet_names():
    print( name )

sheet_1 = book.sheet_by_index(1)#11月分（2番目）のデータ
print( "==========================================")
print( sheet_1.name )
"""
for row in range(sheet_1.nrows):
    #print( '----------------------------')
    for col in range(sheet_1.ncols):
        print( sheet_1.cell(row, col).value )
"""
#########################################################
import pandas as pd
df = pd.read_csv('./dataR1-R2.csv')
print(type(df))
print(df.shape)
