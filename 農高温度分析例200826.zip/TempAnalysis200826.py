# Based on "Collective Intelligence" sample,
# modified and corrected for Python3.4> by A.Fujii
# 2018/Oct/16

import nmf
import numpy as np
import csv

data = []
with open('ForAnalyze.csv',encoding='utf-8') as f:
    lines = csv.reader(f)
    header = next(lines)
    for line in lines:
        data.append(line)

attributes = header
w,h=nmf.factorize(np.matrix(data,dtype=np.float32),pc=3,iter = 100)
print( h )
print( w )

import newsfeatures
dates = [ str(i+1) for i in range(30)]
topp, pn = newsfeatures.showfeatures(w,h,dates,attributes,out='features.txt')
newsfeatures.showarticles(dates,topp,pn,out='stock.txt')
